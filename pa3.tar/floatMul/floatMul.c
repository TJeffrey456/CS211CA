#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
// https://www.tutorialspoint.com/c_standard_library/limits_h.htm
#include <limits.h>
// https://www.cplusplus.com/reference/cfloat/
#include <float.h>

#define FLOAT_SZ sizeof(float)*CHAR_BIT
#define EXP_SZ (FLOAT_SZ-FLT_MANT_DIG)
#define FRAC_SZ (FLT_MANT_DIG-1)
//defining BIAS
#define BIAS 127

int main(int argc, char *argv[]) {

    // float value = *(float *) &binary; // you are not allowed to do this.
    // unsigned int binary = *(unsigned int*) &value; // you are not allowed to do this.

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    // SETUP

    // first, read the binary number representation of multiplier

    //for multiplier -> mer
    //get sign 
    char buff;
    fscanf(fp,"%c", &buff);
    bool mer_sign = buff=='1';
    // printf("%c", buff);
    // printf("%c\n", mer_sign);

    //get exp field
    int E = 0;
    for(int i=EXP_SZ-1;i>=0;i--){
        fscanf(fp,"%c", &buff);
        E = (buff=='1') ? E + pow(2,i): E;
        // printf("%c", buff);
    }

    int mer_exp = E- BIAS;
    // printf("\nE: %d", E);
    // printf("\nmer_exp: %d\n", mer_exp);

    //get mantissa 
    //frac
    float mer_mantissa = 0;
    int mantissa_pwr = -1;
    for(int i=FRAC_SZ-1;i>=0;i--){
        fscanf(fp,"%c",&buff);
        mer_mantissa = (buff=='1') ? mer_mantissa + pow(2,mantissa_pwr) : mer_mantissa;
        mantissa_pwr--; 
        // printf("%c", buff);
        
    }
    // printf("\n%d", mantissa);

    //assume normalized for now so +1
    mer_mantissa = mer_mantissa +1;
    // printf("\nman: %.16f", mer_mantissa);

    //generate multiplier
    float multiplier =  mer_mantissa * (float)pow(2.0,mer_exp); 
    if(mer_exp == -127 && mer_mantissa == 1.0) multiplier = 0;
    multiplier = (mer_sign) ? -multiplier : multiplier;
    // printf("\nmer: %f", multiplier);

    //BREAK
    //need to throw away new line
    fscanf(fp, "%c", &buff);


    //for multiplicand -> mand
    //get sign 
    fscanf(fp,"%c", &buff);
    bool mand_sign = buff=='1';
    // printf("\n%c", buff);
    // printf("%c\n", mand_sign);

    //get exp field
    E = 0;
    for(int i=EXP_SZ-1;i>=0;i--){
        fscanf(fp,"%c", &buff);
        E = (buff=='1') ? E + pow(2,i): E;
        // printf("%c", buff);
    }

    int mand_exp = E- BIAS;
    // printf("\nmand_E: %d", E);
    // printf("\nmand_exp: %d\n", mand_exp);

    //get mantissa 
    float mand_mantissa = 0;
    mantissa_pwr = -1;
    for(int i=FRAC_SZ-1;i>=0;i--){
        fscanf(fp,"%c",&buff);
        mand_mantissa = (buff=='1') ? mand_mantissa + pow(2,mantissa_pwr) : mand_mantissa;
        mantissa_pwr--; 
        // printf("%c", buff);
        
    }
    // printf("\n%d", mantissa);

    //assume normalized for now so +1
    mand_mantissa = mand_mantissa +1;
    // printf("\nman: %.16f", mand_mantissa);

    //generate multiplicand
    float multiplicand = mand_mantissa * (float)pow(2.0,mand_exp);
    if(mand_exp == -127 && mand_mantissa == 1.0) multiplicand = 0;
    multiplicand = (mand_sign) ? -multiplicand : multiplicand;
    // printf("\nmand: %f", multiplicand);


    // bool multiplier[FLOAT_SZ]; // suggested that you store bits as array of bools; multiplier[0] is the LSB
    // for (int i=FLOAT_SZ-1;i>=0;i--) { // read MSB first as that is what comes first in the file
    //     fscanf(fp, "%c", &buff);
    //     multiplier[i] = buff=='1';
    //     printf("%d", multiplier[i]);
    // }

    // // notice that you are reading two different lines; caution with reading
    // fscanf(fp, "%c", &buff); //to get rid of the new line
    // printf("\n"); //formatting

    // // first, read the binary number representation of multiplcand
    // bool multiplicand[FLOAT_SZ]; // suggested that you store bits as array of bools; multiplicand[0] is the LSB
    // for (int i=FLOAT_SZ-1;i>=0;i--) { // read MSB first as that is what comes first in the file
    //     fscanf(fp, "%c", &buff);
    //     multiplicand[i] = buff=='1';
    //     printf("%d", multiplicand[i]);
    // }

    float product = *(float *) &multiplier * *(float *) &multiplicand; // you are not allowed to print from this.
    unsigned int ref_bits = *(unsigned int *) &product; // you are not allowed to print from this. But you can use it to validate your solution.
    // printf("\nprod: %.12f ", product);
    // SIGN
    bool sign = mer_sign ^ mand_sign;;
    printf("%d_",sign);
    assert (sign == (1&ref_bits>>(EXP_SZ+FRAC_SZ)));

    // EXP
    // get the exp field of the multiplier and multiplicand
    /* ... */
    // add the two exp together
    int exp = (mer_exp + mand_exp) + BIAS;
    // subtract bias
    /* ... */

    //ignore given code
    

    // FRAC
    // get the frac field of the multiplier and multiplicand
    /* ... */
    // assuming that the input numbers are normalized floating point numbers, add back the implied leading 1 in the mantissa
    /* ... */
    // multiply the mantissas
    float mantissa = mer_mantissa * mand_mantissa;
    // printf("\nprod_mantissa: %f\n", mantissa);

    //IGNORING given code

    // overflow and normalize
    //I need to account for if the mantissa is greater than one 
    while (mantissa>=2.0){
        mantissa /=2;// I want to divide by 2
        exp++;//and raise the pwr of 2 of the exponent
    }
    

    //getting mantissa ready to print
    float fraction = mantissa;

    //printf("\n%f\n", fraction);
    fraction = (abs(fraction)>=1) ? fraction-1 : fraction;
    //printf("\n%f\n", fraction); 
    //need to be able to keep track of what pwr of 2 I am on
    int frac_bit_exp = -1;//normal : denormalized (fraction<1) ? 0 : 

    bool frac_array[FRAC_SZ+1]; // one extra LSB bit for rounding
    for ( int frac_index=FRAC_SZ; 0<=frac_index; frac_index-- ) {
        //frac_array[frac_index] = false; // frac set to zero to enable partial credit
        frac_array[frac_index] = (fraction - pow(2, frac_bit_exp))>=0.0;
        if(frac_array[frac_index]){
            fraction = fraction - pow(2,frac_bit_exp);
        }
        frac_bit_exp--;
    }
    // rounding
    /* ... */

    // move decimal point
    /* ... */

    // // PRINTING
    // print exp
    for ( int bit_index=EXP_SZ-1; 0<=bit_index; bit_index-- ) {
        bool trial_bit = 1&exp>>bit_index;
        printf("%d",trial_bit);
        // printf(" %d\n", (1&ref_bits>>(bit_index+FRAC_SZ)));
        assert (trial_bit == (1&ref_bits>>(bit_index+FRAC_SZ)));
    }
    printf("_");

    // // print frac
    // for ( int bit_index=FRAC_SZ-1; 0<=bit_index; bit_index-- ) {
    //     bool trial_bit = 1&fraction>>bit_index;
    //     printf("%d",trial_bit);
    //     // assert (trial_bit == (1&ref_bits>>(bit_index)));
    // }

    //use printing method for doubleToBin
    for ( int frac_index=FRAC_SZ-1; 0<=frac_index; frac_index-- ) {
        bool frac_bit = frac_array[frac_index+1]; // skipping the extra LSB bit for rounding
        printf("%d", frac_bit);
        // printf(" %d\n", (1&ref_bits>>(frac_index)));
        assert (frac_bit == (1&ref_bits>>(frac_index))); // validate your result against the reference
        //asset works for everything except first test case
    }


    return(EXIT_SUCCESS);

}
