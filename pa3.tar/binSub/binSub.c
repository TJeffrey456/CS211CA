#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
// https://www.tutorialspoint.com/c_standard_library/limits_h.htm
#include <limits.h>

int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    // SETUP

    // first, read the minuend (number to be subtracted from)
    char buff;
    bool minuend[CHAR_BIT]; // suggested that you store bits as array of bools; minuend[0] is the LSB
    for (int i=CHAR_BIT-1; 0<=i; i--) { // read MSB first as that is what comes first in the file
        fscanf(fp, "%c", &buff);
        minuend[i] = (buff=='1') ? true : false;
        //printf("%d", minuend[i]);
    }

    // notice that you are reading two different lines; caution with reading
    fscanf(fp, "%c", &buff);
    //this is just to not scan the new line and discard it
    //printf("\n");//new line for formating 

    // second, read the subtrahend (number to subtract)
    bool subtrahend[CHAR_BIT]; // suggested that you store bits as array of bools; subtrahend[0] is the LSB
    for (int i=CHAR_BIT-1; 0<=i; i--) { // read MSB first as that is what comes first in the file
        fscanf(fp, "%c", &buff);
        subtrahend[i] = (buff=='1') ? true : false;
        //printf("%d", subtrahend[i]);
    }

    // WE WILL DO SUBTRACTION BY NEGATING THE SUBTRAHEND AND ADD THAT TO THE MINUEND

    // printf("\n");//new line for formating 
    // Negate the subtrahend
    // flip all bits
    for(int i = CHAR_BIT-1; i>=0;i--){
        subtrahend[i] = !subtrahend[i];
    }

    // add one
    bool carry = true; 
    //having it set to true is the same as adding one 
    // to implement the 'add one' logic, we do binary addition logic with carry set to true at the beginning
    for (int i=0; i<CHAR_BIT; i++) { // iterate from LSB to MSB
        bool subtrahend_before = subtrahend[i];
        subtrahend[i] = carry ^ subtrahend[i];
        carry = (carry&&subtrahend_before);
    }

    //set carry to false bc we never have to carry on the first addition
    carry = false;
    // Add the minuend and the negated subtrahend
    bool difference[CHAR_BIT];
    for(int i = 0; i<CHAR_BIT; i++){
        // printf("%d", carry);
        //add the two w/ carry
        difference[i] = carry ^ (minuend[i] ^ subtrahend[i]);
        //figure out if I need to carry
        carry = (carry && minuend[i]) || (carry && subtrahend[i]) || (minuend[i] && subtrahend[i]);

    }

    // printf("\n");//format
    // //pritn minuend
    // for (int i=CHAR_BIT-1; 0<=i; i--)
    //     printf("%d",minuend[i]);
    // printf("\n");//format
    // //print subtrahend
    // for (int i=CHAR_BIT-1; 0<=i; i--)
    //     printf("%d",subtrahend[i]);

    // printf("\n");//new line for formating 
    // print the difference bit string
    for (int i=CHAR_BIT-1; 0<=i; i--)
        printf("%d",difference[i]);

    return EXIT_SUCCESS;

}
