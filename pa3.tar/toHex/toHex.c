#include <stdlib.h>
#include <stdio.h>

#include <math.h>
//he included -lm so I dont see why not

//method to take an integer of 0<= x <= 15 and convert it to hex
char convertToHex( int nibble){
    char hexIndex[16] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
    return hexIndex[nibble];
}

int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return 0;
    }

    // first, read the number
    signed int input;
    fscanf(fp, "%d", &input);

    //instead of printing the bits I'm going to save them to an array of 32 bits
    //32 bc that is the guarenteed bound
    //first bit is last in array, last is first in array
    char* bitArray = (char*)calloc(32,sizeof(char));

    // print bits; you will see this kind of for loop often in this assignment
    for ( int bit=sizeof(signed int)*8-1; 0<=bit; bit-- ) {
        size_t bit_val = ((1<<1)-1) & input>>bit*1; // shift and mask
        char character = bit_val ? '1' : '0';
        bitArray[bit] = character;
        //printf("%c",bitArray[bit]);
    }
    //printf("\n");

    //CANNOT READ, all the answers are in the form of 4 hex 
    // //need to figure out a systematic way to figure out how many digits I should care about 
    // //use log2 on the abs of input
    // int numOfBits = (int)ceil(log2((double)(abs(input))));
    // //printf("%d ", numOfBits);
    // //add 1 if input is less than 0
    // numOfBits = (input<0) ? numOfBits+1 : numOfBits;
    // // //divide by 8.0 and use ceil
    // int numOfBytes = (int)ceil(((double)numOfBits)/8.0);
    // //now I have the number of bytes 

    char* hex = (char*)calloc(8,sizeof(char));
    // //break up into nimbles and save that to a char*

    //there are 4 bytes
    for(int i=0; i<4;i++){
        //there are 2 nibbles in each byte
        for(int j=0; j<2; j++){
            //each nibble has 4 bits, and one hex
            unsigned nibble = 0;
            double pwerOf2 = 0.0;
            int readBit;
            for(int k=0; k<4; k++){
                //start backwards
                //add bits
                //have to make char to int
                
                readBit = (bitArray[ (8*i) + (4*j) + (k)] == '1') ? 1 : 0; 
                //printf(" %d ", readBit);
                nibble = nibble + (readBit*(int)pow(2.0,pwerOf2));
                pwerOf2++;
                //printf("%d.", nibble);
            }
            hex[7-(2*i)-(j)] = convertToHex(nibble);
            
        }
    }
    
    //print hex
    for(unsigned i=4; i<8; i++){
        printf("%c", hex[i]);
    }


    //free
    free(bitArray);
    free(hex);

    return EXIT_SUCCESS;

}
