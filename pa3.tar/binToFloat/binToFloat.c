#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define EXP_SZ 8
#define FRAC_SZ 23

//adding a define for bias
#define BIAS 127

int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    // SETUP

    // first, read the binary number representation of float point number
    char buff;
    //unsigned int binary = 0;
    //I dont get the pt of saving it in a int and not an  array
    unsigned int binary[32];
    for (int i=EXP_SZ+FRAC_SZ; 0<=i; i--) { // read MSB first as that is what comes first in the file
        fscanf(fp, "%c", &buff);
        binary[i] = (buff=='1') ? 1 : 0;
        //printf("%d", binary[i]);
    }

    // float number = *(float *)&binary; // you are not allowed to do this.

    // I need sign which is at the MSB @31
    int sign = binary[EXP_SZ+FRAC_SZ];

    // E
    //binary part encodes the exp
    
    //I need decimal rep of exp, from 30 to 23
    double decimal = 0;
    double base = 1;

    for (unsigned i = FRAC_SZ; i <FRAC_SZ+EXP_SZ; i++) {
        decimal += (double)binary[i] * base;
        base *= 2;
        //printf("\n%f", decimal);
    }
    double exp = decimal;
    // exp = E + BIAS 
    //I want E so
    //E = exp - bias
    int e = (int)exp - BIAS;
    // printf("\n%d", e);

    // M
    // m = 1.frac
    decimal = 0;
    base = 0.5;
    for (int i = FRAC_SZ-1; i >=0; i--) {
        decimal += (double)binary[i] * base;
        base /= 2.0;
    }
    double frac = decimal;
    double m = 1 + frac;
    //printf("\n%.100f\n", m);

    // https://www.tutorialspoint.com/c_standard_library/c_function_ldexp.htm
    double number = ldexp ( m, e );
    number = sign ? -number : number;
    printf("%e\n", number);

    return EXIT_SUCCESS;

}
