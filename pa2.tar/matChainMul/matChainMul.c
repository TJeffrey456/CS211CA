#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include "../matMul/matMul.h"

//provided code that I am just disregarding
unsigned int cost (
    unsigned int matrixCount,
    unsigned int* rowSizes,
    unsigned int* colSizes
) {
    if ( matrixCount==1 ) { // Base case.
        return 0; // No multplication to be done.
    } else {

        unsigned int numPossibleSplits = matrixCount-1; // Think: if there are two matrices to multiply, there is one way to split.
        // AB: (A)(B)
        // ABC: (A)(BC) and (AB)(C)

        unsigned int costs[numPossibleSplits];
        for ( unsigned int split=0; split<numPossibleSplits; split++ ) {

            unsigned int l = rowSizes[0];
            assert ( colSizes[split] == rowSizes[split+1] );
            unsigned int m = colSizes[split];
            unsigned int n = colSizes[matrixCount-1];

            costs[split] =
                cost( split+1, rowSizes, colSizes ) + // cost of left subchain
                l * m * n + // cost of multiplying the two chains
                cost( matrixCount-split-1, rowSizes+split+1, colSizes+split+1 ); // cost of right subchain
        }

        unsigned int minCost = costs[0];
        for ( unsigned int split=1; split<numPossibleSplits; split++ ) {
            if ( costs[split]<minCost ) {
                minCost = costs[split];
            }
        }

        return minCost;
    }
}


//method to find the cost of matrix chain multiplication using DP
//n is the number of matrices
//m is to hold the cost of each matrix to do this dynamically
int costDP(int p[], int n, int** costMatrix, int** mulOrder) {
    int i, j, k, l, q;
    
    for (i = 0; i < n; i++) {
        costMatrix[i][i] = 0;
    }
    
    for (l = 2; l <= n; l++) {
        for (i = 0; i < n - l + 1; i++) {
            j = i + l - 1;
            costMatrix[i][j] = 999999;
            for (k = i; k < j; k++) {
                q = costMatrix[i][k] + costMatrix[k+1][j] + p[i]*p[k+1]*p[j+1];
                if (q < costMatrix[i][j]) {
                    costMatrix[i][j] = q;
                    mulOrder[i][j] = k;
                }
            }
        }
    }
    
    return costMatrix[0][n-1];
}


// int* findOrder(int numMatrices, int** mulOrder, int i, int j, int* partition, int* properOrder, int properOrderLength) {
//     if (numMatrices == 1) return properOrder;
//     *partition = mulOrder[i][j];
//     i = (*partition == i) ? i + 1 : i;
//     j = *partition;
//     properOrder[--properOrderLength] = *partition;
//     numMatrices--;
//     return findOrder(numMatrices, mulOrder, i, j, partition, properOrder, properOrderLength);
// }

//recursive function to multiply the matrices
//i is the row of mulOrder
//j is the col of mulOrder
int** multiplyMatrix(int*** matrices, int* dimensions, int i, int j, int** mulOrder, int** product){
    if (i == j) {
        return matrices[i];
    } else {
        //need 2 extra temp matrix to multiply
        int** temp1 = (int**)calloc(10, sizeof(int*));
        int** temp2 = (int**)calloc(10, sizeof(int*));
        for(unsigned i=0;i<10;i++){
            temp1[i] = (int*)calloc(10, sizeof(int));
            temp2[i] = (int*)calloc(10, sizeof(int));
        }

        int** left = multiplyMatrix(matrices, dimensions, i, mulOrder[i][j], mulOrder, temp1);
        int** right = multiplyMatrix(matrices, dimensions, mulOrder[i][j] + 1, j, mulOrder, temp2);

        // Multiply the results of the two subproblems
        matMul(dimensions[i], dimensions[mulOrder[i][j] + 1], dimensions[j + 1], left, right, product);
        

        //free the temp matrix
        for(unsigned i=0;i<10;i++){
            free(temp1[i]);
            free(temp2[i]);
        }
        free(temp1);
        free(temp2);

        //return the final product 
        return product;
    }
}

int main(int argc, char* argv[]) {

    unsigned int matrixCount;
    unsigned int* rowSizes;
    unsigned int* colSizes;
    int*** matrices;

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        exit(EXIT_FAILURE);
    }

    if (!fscanf(fp, "%d\n", &matrixCount)) {
        perror("reading the number of matrices failed");
        exit(EXIT_FAILURE);
    }

    rowSizes = calloc( matrixCount, sizeof(int) );
    colSizes = calloc( matrixCount, sizeof(int) );
    matrices = calloc( matrixCount, sizeof(int**) );
    for (unsigned int matIndex=0; matIndex<matrixCount; matIndex++) {

        unsigned int rows, cols;
        if (!fscanf(fp, "%d %d\n", &rows, &cols)) {
            perror("reading the dimensions of matrix failed");
            exit(EXIT_FAILURE);
        }
        rowSizes[matIndex] = rows;
        colSizes[matIndex] = cols;

        matrices[matIndex] = calloc( rows, sizeof(int*) );
        for ( unsigned int i=0; i<rows; i++ ) {
            matrices[matIndex][i] = calloc( cols, sizeof(int) );
            for ( unsigned int k=0; k<cols; k++ ) {
                int element;
                if (!fscanf(fp, "%d ", &element)) {
                    perror("reading the element of matrix failed");
                    exit(EXIT_FAILURE);
                }
                matrices[matIndex][i][k] = element;
            }
        }
    }
    //provided code
    // unsigned int mul_op_count = cost ( matrixCount, rowSizes, colSizes );
    // printf("%d\n", mul_op_count );


    //hold the dimensions of the given matrices
    int n = matrixCount;
    int* dimensions =(int*)calloc(n+1, sizeof(int)); 
    //get the first and last dimensions and save them and use a loop on even numbers to get the rest
    dimensions[n] = colSizes[n-1];
    for(unsigned i=0;i<n;i++){
        dimensions[i] = rowSizes[i];
        //printf("%d ", rowSizes[i]);
    }
    //printf("%d ", dimensions[n]);
    //print statements were for testing if dimensions were correct

    //malloc costMatrix
    int** costMatrix = (int**)calloc(n,sizeof(int*));
    for(unsigned i=0; i<n; i++){
        costMatrix[i] = (int*)calloc(n,sizeof(int));
    }
    //malloc mulOrder
    int ** mulOrder = (int**)calloc(n,sizeof(int*));
    for(unsigned i=0; i<n; i++){
        mulOrder[i] = (int*)calloc(n,sizeof(int));
    }

    //I need to compute the matrix using DP and output it HERE
    costDP(dimensions, n, costMatrix, mulOrder);
    //the index of minCost is [0][n-1]
    
    

    //need to malloc for product and do mathdimensions[0]dimensions[n]
    int ** product = (int**)calloc(10,sizeof(int*));
    for(unsigned i=0; i<10; i++){
        product[i] = (int*)calloc(10,sizeof(int));
    }

    //doing math
    //I can do it by cases and cry
    product = multiplyMatrix(matrices, dimensions, 0, n-1, mulOrder, product);


    //print product
    for(unsigned i=0; i<dimensions[0];i++){
        for(unsigned j=0;j<dimensions[n];j++){
            printf("%d ", product[i][j]);
        }
        printf("\n");
    }

    //my stuff to free 
    free(dimensions);
    for(unsigned i=0; i<n; i++){
        free(costMatrix[i]);
        free(mulOrder[i]);
    }
    free(costMatrix);
    free(mulOrder);

    //free product
    for(unsigned i=0;i<10;i++){
        free(product[i]);
    }
    free(product);

    //provided free
    for (unsigned int matIndex=0; matIndex<matrixCount; matIndex++) {
        int rows = rowSizes[matIndex];
        for ( unsigned int i=0; i<rows; i++ ) {
            free(matrices[matIndex][i]);
        }
        free(matrices[matIndex]);
    }
    free(matrices);

    free(colSizes);
    free(rowSizes);
    fclose(fp);

    exit(EXIT_SUCCESS);
}
