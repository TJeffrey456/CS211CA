#include "../graphutils.h" // header for functions to load and free adjacencyList
#include "../queue/queue.h" // header for queue

// A program to solve a maze that may contain cycles using BFS

int main ( int argc, char* argv[] ) {

    //this skel code is so stupid so save the arguments and then pass them through
    char* testFile = argv[1];
    char * queryFile = argv[2];
    // First, read the query file to get the source and target nodes in the maze
    FILE* fp = fopen(queryFile, "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }
    int source, target;
    fscanf(fp, "%d", &source);
    fscanf(fp, "%d", &target);

    // READ INPUT FILE TO CREATE GRAPH ADJACENCY LIST
    AdjacencyListNode* adjacencyList = NULL;
    size_t graphNodeCount = adjMatrixToList(testFile, &adjacencyList);

    // USE A QUEUE TO PERFORM BFS
    Queue queue = { .front=NULL, .back=NULL };

    // An array that keeps track of who is the parent node of each graph node we visit
    graphNode_t* parents = calloc( graphNodeCount, sizeof(graphNode_t) );
    for (size_t i=0; i<graphNodeCount; i++) {
        parents[i] = -1; // -1 indicates that a nodes is not yet visited
    }
    //I want to start at the source which is the row that source is the first element
    int current = (int)(adjacencyList[source].graphNode);
    //- it will be the first one so it will be visited bc I dont want to add it to the queue bc it will have +1 iteration
    parents[current] = source; //I got to source via source bc I started

    while ( current != target ) {

        // so long as we haven't found the target node yet, iterate through the adjacency list
        // add each neighbor that has not been visited yet (has no parents) to the queue of nodes to visit

        //- I want to go to where the current is located and check its neighbors
        AdjacencyListNode* adj_vertices = adjacencyList[current].next;
        while(adj_vertices != NULL){
            if(parents[(int)adj_vertices->graphNode]==-1){
                enqueue(&queue, adj_vertices);
                //- I want to say I have now visited this vertex
                parents[(int)adj_vertices->graphNode] = current;//set the parent to current - how we got there
            }
            adj_vertices = adj_vertices->next;
        }
        // Visit the next node at the front of the queue of nodes to visit
        current = *((int*)(dequeue(&queue)));
    }

    // Now that we've found the target graph node, use the parent array to print maze solution
    // Print the sequence of edges that takes us from the source to the target node
    //edgelists are the answers to this program
    int sol_loc = target;
    graphNode_t solution = parents[sol_loc];
    
    do{
        printf("%d %d\n",(int)solution ,sol_loc);
        sol_loc = (int)solution;
        solution = parents[solution];
    }while(sol_loc!=source);



    // free any queued graph nodes that we never visited because we already solved the maze
    while ( queue.front ) { //proper way to do it so possible to fix BSTLevelOrder
        dequeue(&queue);
    }
    free (parents);
    freeAdjList ( graphNodeCount, adjacencyList );

    return EXIT_SUCCESS;
}
