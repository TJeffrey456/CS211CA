#include "../graphutils.h"

// A program to find a cycle in a directed graph

//helper method to see if a value already exists in a set
bool visited (unsigned length, int path[length], unsigned target){
    for(unsigned i=0;i<length;i++){
        if(path[i]==target){
            return true;
        }
    }
    return false;
}

//method to recursive print all the paths for a cycle
void printCycle (unsigned start, int length, int path[length], unsigned parent){

    //I want to do a DFS for the path array until parent is equal to the start
    //print the last thing first and then print the rest
    if(start==parent){
        printf("%d ", parent);
        return;
    } 
    printCycle(start, length, path, path[parent]);
    printf("%d ", parent);
}

//makes all values in a given array -1
void resetArr(unsigned length, int arr[length]){
    for(unsigned i=0;i<length;i++){
            arr[i]=-1;
    }
}

// You may use DFS or BFS as needed
/*  start is the node we are currently examining
    adjList is the list of adjacent nodes to the current node
    length is the length of the array we are passing in
    path is the array that holds the parents of the nodes we have visited already
    parent is the node of how we got to start
*/
bool CycleDFS (
    unsigned start, 
    AdjacencyListNode* adjList,
    int length, 
    int path[length],
    unsigned parent
    ){
    //I have to check if we have already visited this vertex
    if(visited(length, path, start)){//if I have theres a cycle
        printCycle(start, length, path, parent);
        return true;
    } else {//else visit it and check its neighbors
        //mark it as visited now by marking its parent 
        path[start] = parent;
        
    }
    //call DFS on each neighbor
    AdjacencyListNode* neighbor = adjList[start].next;
    while (neighbor) {
        if(CycleDFS(neighbor->graphNode, adjList, length, path, start)){
            return true;
        }
        // printf ("%d ", (int)neighbor->graphNode);
        neighbor = neighbor->next;
    }
    path[start] = -1;

    return false;
}


int main ( int argc, char* argv[] ) {

    // READ INPUT FILE TO CREATE GRAPH ADJACENCY LIST
    AdjacencyListNode* adjacencyList;
    graphNode_t graphNodeCount = adjMatrixToList(argv[1], &adjacencyList);

    //make a parent array of ints where -1 is not visited and each element holds its parent
    int* parents = (int*)calloc(graphNodeCount, sizeof(int));
    resetArr(graphNodeCount, parents);//might run into time issues w/ this

    bool isCyclic = false;
    for (unsigned source=0; source<graphNodeCount; source++) {
        //so I can use it as an argument and it will not have data from a previous run
        

        //Call DFS on source 
        isCyclic = CycleDFS(source, adjacencyList, graphNodeCount, parents, source);
        if(isCyclic) break;
    }

    if (!isCyclic) { printf("DAG\n"); }
    //^provided

    //free parents
    free(parents);
    freeAdjList ( graphNodeCount, adjacencyList );
    return EXIT_SUCCESS;
}
