#include <stdlib.h>
#include <stdio.h>
#include "../bstReverseOrder/bst.h"
#include "../queue/queue.h"

// A program to perform a LEVEL ORDER (BREADTH-FIRST) TRAVERSAL of a binary search tree

int main ( int argc, char* argv[] ) {

    // READ INPUT FILE TO CREATE BINARY SEARCH TREE
    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }
    BSTNode* root = NULL;
    int key;
    while ( fscanf(fp, "%d", &key)!=EOF ) {
        root = insert (root, key);
    }
    fclose(fp);

    // USE A QUEUE TO PERFORM LEVEL ORDER TRAVERSAL
    Queue queue = { .front=NULL, .back=NULL };
    Queue* q_ptr = &queue;

    //add something to the queue
    enqueue(q_ptr, root);
    
    BSTNode* q_content;
    //level order
    do{
        q_content = (BSTNode*)dequeue(q_ptr);
        printf("%d ", q_content->key);
        if(q_content->l_child!=NULL){
        enqueue(q_ptr, q_content->l_child);
        }
        if(q_content->r_child!=NULL){
            enqueue(q_ptr, q_content->r_child);
        }
    }while(q_ptr->front!=NULL);

    delete_bst(root);
    return EXIT_SUCCESS;
}
