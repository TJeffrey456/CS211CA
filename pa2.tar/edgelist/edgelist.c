#include "../graphutils.h" // header for functions to load and free adjacencyList

// A program to print the edge list of a graph given the adjacency matrix
int main ( int argc, char* argv[] ) {

    // FIRST, READ THE ADJACENCY MATRIX FILE
    AdjacencyListNode* adjacencyList = NULL;
    
    //read in the number of nodes and load the adjlist;
    size_t numOfNodes = adjMatrixToList(argv[1], &adjacencyList);

    // NEXT, TRAVERSE THE ADJACENCY LIST AND PRINT EACH EDGE, REPRESENTED AS A PAIR OF NODES
    // Example of traversing the adjacency list is in the freeAdjList() function in graphutils.h
    //make a visited array and traverse the array of adjacencyLists
    //int visited[numOfNodes]; 
    for(size_t i=0; i<numOfNodes; i++){
        //visited[i] = 1;
        for(AdjacencyListNode* ptr=&adjacencyList[i]; ptr!=NULL; ptr = ptr->next){
            if(i < ptr->graphNode) {
            //if(visited[ptr->graphNode]==0){    
                printf("%d %d\n", (int)i, (int)ptr->graphNode);
            }
            //visited[ptr->graphNode]=1;
        }
    }

    // NOW, BE SURE TO FREE THE ADJACENCY LIST
    freeAdjList(numOfNodes, adjacencyList);

    return EXIT_SUCCESS;
}
